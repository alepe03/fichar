// Archivo de configuración global de la app

// URL base de la API para todas las peticiones HTTP
const String BASE_URL = "https://www.trivalle.com/apiFichar/trvFichar.php";
